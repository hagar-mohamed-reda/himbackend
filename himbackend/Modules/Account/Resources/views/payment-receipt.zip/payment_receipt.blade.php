
@php
    $service = \Modules\Account\Entities\Service::find($payment->model_id);
@endphp
@if ($payment->model_type == 'service' && optional($service)->type == 'in')
@include('account::in', ["payment" => $payment])
@else
@include('account::wz', ["payment" => $payment])
@endif